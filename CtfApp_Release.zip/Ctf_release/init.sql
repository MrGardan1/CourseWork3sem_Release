-- ============================================
-- Создание таблиц (структура)
-- ============================================

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS "Users" (
    "Id" SERIAL PRIMARY KEY,
    "Username" VARCHAR(100) NOT NULL UNIQUE,
    "Password" VARCHAR(255) NOT NULL,
    "Score" INTEGER DEFAULT 0,
    "IsAdmin" BOOLEAN DEFAULT FALSE,
    "CreatedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица задач
CREATE TABLE IF NOT EXISTS "Tasks" (
    "Id" SERIAL PRIMARY KEY,
    "Category" VARCHAR(50) NOT NULL,
    "Difficulty" VARCHAR(20) NOT NULL,
    "Title" VARCHAR(200) NOT NULL,
    "Description" TEXT NOT NULL,
    "Flag" VARCHAR(100) NOT NULL,
    "Points" INTEGER NOT NULL,
    "Hint" TEXT,
    "Solution" TEXT
);

-- Таблица связи пользователей и задач (решённые задачи)
CREATE TABLE IF NOT EXISTS "UserTasks" (
    "Id" SERIAL PRIMARY KEY,
    "UserId" INTEGER NOT NULL REFERENCES "Users"("Id") ON DELETE CASCADE,
    "TaskId" INTEGER NOT NULL REFERENCES "Tasks"("Id") ON DELETE CASCADE,
    "SolvedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE("UserId", "TaskId")
);

-- ============================================
-- Вставка задач
-- ============================================

-- Очищаем старые данные (если перезапуск)
TRUNCATE TABLE "UserTasks" CASCADE;
TRUNCATE TABLE "Tasks" RESTART IDENTITY CASCADE;

-- ============================================
-- 🌐 WEB EXPLOITATION (6 задач)
-- ============================================

INSERT INTO "Tasks" ("Category", "Difficulty", "Title", "Description", "Flag", "Points", "Hint", "Solution") VALUES
('Web', 'Easy', 'HTTP Methods', 
'HTTP работает по принципу запрос-ответ. Какой метод используется для ПОЛУЧЕНИЯ данных с сервера?

💡 Подсказка: этот метод не изменяет данные, только читает. Формат: flag{METHOD}', 
'flag{GET}', 10,
'Этот метод используется когда вы открываете любую страницу в браузере.',
'GET — самый распространённый HTTP метод. Используется для получения данных с сервера без изменения состояния. Другие методы: POST (отправка), PUT (обновление), DELETE (удаление).'),

('Web', 'Easy', 'Cookie Inspector', 
'Сайт установил cookie: session=ZmxhZ3tjb29raWVzfQ==

Это Base64. Декодируй и найди флаг!

💡 Используй: base64decode.org', 
'flag{cookies}', 15,
'Скопируй строку ZmxhZ3tjb29raWVzfQ== и вставь на сайт base64decode.org',
'Base64 — это способ кодирования бинарных данных в текст. Часто используется в cookies, JWT токенах, email. Декодировать: echo "ZmxhZ3tjb29raWVzfQ==" | base64 -d'),

('Web', 'Easy', 'URL Encoding', 
'Декодируй URL: flag%7Burl%5Fdecode%7D

💡 %7B = {, %7D = }, %5F = _', 
'flag{url_decode}', 10,
'URL encoding заменяет специальные символы на %XX, где XX — hex код символа.',
'URL encoding нужен для безопасной передачи данных в URL. Символы { } _ кодируются как %7B %7D %5F. Декодировать можно на urldecoder.org или в браузерной консоли: decodeURIComponent("flag%7Burl%5Fdecode%7D")'),

('Web', 'Medium', 'HTTP Status Codes', 
'Какой HTTP статус код означает "Not Found" (страница не найдена)?

Формат: flag{код}', 
'flag{404}', 20,
'Когда страница не найдена, сервер возвращает этот код. Самый известный код ошибки!',
'404 Not Found — страница не существует. Другие коды: 200 OK (успех), 403 Forbidden (нет доступа), 500 Internal Server Error (ошибка сервера), 301 Moved Permanently (редирект).'),

('Web', 'Medium', 'User-Agent Header', 
'HTTP заголовок User-Agent содержит информацию о браузере. Декодируй Base64:
VXNlci1BZ2VudDogZmxhZ3t1c2VyX2FnZW50fQ==

Найди флаг!', 
'flag{user_agent}', 25,
'Это Base64. Декодируй на base64decode.org',
'User-Agent — HTTP заголовок, содержащий информацию о браузере и ОС. Пример: Mozilla/5.0 (Windows NT 10.0; Win64; x64). Используется для статистики и адаптации контента.'),

('Web', 'Hard', 'SQL Comment Syntax', 
'В SQL Injection используются комментарии для обхода проверок. Какая последовательность символов создаёт комментарий в SQL?

Варианты: #, --, //, /* */

Формат: flag{символы} (например: flag{--})', 
'flag{--}', 40,
'Это два дефиса подряд. После них весь остаток строки игнорируется.',
'В SQL комментарий -- обрывает запрос. Пример атаки: SELECT * FROM users WHERE username = "admin"--" AND password = "x" — пароль игнорируется! Защита: prepared statements, экранирование.');

-- ============================================
-- 🔐 CRYPTOGRAPHY (6 задач)
-- ============================================

INSERT INTO "Tasks" ("Category", "Difficulty", "Title", "Description", "Flag", "Points", "Hint", "Solution") VALUES
('Crypto', 'Easy', 'Caesar Cipher', 
'Шифр Цезаря со сдвигом 3. Расшифруй: iodj{fdhvdu}

💡 A→D, B→E, C→F... Сдвиг на 3 назад', 
'flag{caesar}', 15,
'Каждую букву сдвигаем на 3 позиции НАЗАД в алфавите. i→f, o→l, d→a...',
'Шифр Цезаря — подстановочный шифр, где каждая буква сдвигается на N позиций. Уязвим к частотному анализу (всего 25 вариантов сдвига). Историческая значимость: использовался Юлием Цезарем.'),

('Crypto', 'Easy', 'Base64 Decode', 
'Base64 — кодирование, не шифрование. Декодируй:
ZmxhZ3tiYXNlNjR9

💡 base64decode.org или: echo "ZmxhZ3tiYXNlNjR9" | base64 -d', 
'flag{base64}', 10,
'Используй base64decode.org или команду: echo "ZmxhZ3tiYXNlNjR9" | base64 -d',
'Base64 кодирует 3 байта в 4 символа (A-Z, a-z, 0-9, +, /). Не шифрование! Используется для передачи бинарных данных в текстовом формате (email, JSON, XML).'),

('Crypto', 'Easy', 'ROT13', 
'ROT13 — шифр со сдвигом 13. Расшифруй: synt{ebgsvegrra}

💡 rot13.com', 
'flag{rotfifteen}', 10,
'ROT13 — это Цезарь со сдвигом 13. Примени дважды для расшифровки!',
'ROT13 уникален: шифрование = расшифровка (13 — половина алфавита). Используется для скрытия спойлеров в интернете. Команда: echo "synt{ebgsvegrra}" | tr A-Za-z N-ZA-Mn-za-m'),

('Crypto', 'Medium', 'Hex to ASCII', 
'Шестнадцатеричная система. Декодируй:
666c61677b6865785f746f5f61736369697d

💡 Hex decoder или: echo "..." | xxd -r -p', 
'flag{hex_to_ascii}', 20,
'Hex — шестнадцатеричная система (0-9, A-F). Каждые 2 символа = 1 байт.',
'Hex часто используется для представления бинарных данных. Пример: 41 = A, 42 = B. Декодировать: echo "666c61677b..." | xxd -r -p или онлайн hex decoder.'),

('Crypto', 'Medium', 'Binary to Text', 
'Двоичная система (каждые 8 бит = 1 символ). Декодируй:
01100110 01101100 01100001 01100111 01111011 01100010 01101001 01101110 01100001 01110010 01111001 01111101

💡 Binary to text converter', 
'flag{binary}', 25,
'Каждые 8 бит (0 или 1) = 1 символ ASCII. 01100110 = 102 = "f"',
'Binary (двоичная система) — основа компьютеров. 8 бит = 1 байт = 1 ASCII символ. Пример: 01000001 = 65 = A. Конвертер: echo "01100110" | perl -lpe "$_=pack\"B*\",$_"'),

('Crypto', 'Hard', 'MD5 Hash Type', 
'MD5 создаёт хеш длиной 128 бит. Сколько это символов в hex представлении?

Формат: flag{число}', 
'flag{32}', 35,
'128 бит = 128 / 8 = 16 байт. Каждый байт = 2 hex символа.',
'MD5 создаёт 128-битный хеш = 16 байт = 32 hex символа. Пример: d41d8cd98f00b204e9800998ecf8427e. MD5 небезопасен (коллизии)! Используй SHA-256, SHA-3 или bcrypt для паролей.');

-- ============================================
-- 🔍 FORENSICS (6 задач)
-- ============================================

INSERT INTO "Tasks" ("Category", "Difficulty", "Title", "Description", "Flag", "Points", "Hint", "Solution") VALUES
('Forensics', 'Easy', 'File Signatures', 
'Какой тип файла начинается с байтов: 50 4B?

Справка:
• PNG: 89 50 4E 47
• JPEG: FF D8 FF
• ZIP: 50 4B
• PDF: 25 50 44 46

Формат: flag{type} (lowercase)', 
'flag{zip}', 15,
'P и K — это первые буквы названия формата архива.',
'ZIP файлы начинаются с 50 4B (PK — инициалы Phil Katz, создателя формата). Команда file определяет тип по магическим байтам. Инструмент: hexdump -C file.zip | head'),

('Forensics', 'Easy', 'Strings Command', 
'Команда "strings" извлекает текст из файлов. Представь что в файле строка:
"Hidden: flag{strings_useful}"

Найди флаг!', 
'flag{strings_useful}', 10,
'Команда strings извлекает все читаемые строки из файла.',
'strings — утилита для извлечения текста из бинарников. Пример: strings binary.exe | grep flag. Полезно для анализа исполняемых файлов, дампов памяти, изображений со спрятанными данными.'),

('Forensics', 'Easy', 'File Command', 
'Команда "file" определяет тип. Если расширение .txt, но file показывает "PNG image", какое расширение правильное?

Формат: flag{ext} (без точки)', 
'flag{png}', 10,
'Если file говорит PNG, значит это PNG изображение!',
'Команда file использует магические байты для определения типа. Трюк: злоумышленники меняют расширение для обхода фильтров. Всегда проверяй: file suspicious.txt'),

('Forensics', 'Medium', 'EXIF Tool', 
'Какая команда показывает метаданные изображений/PDF?

Варианты: exif, exiftool, metadata, fileinfo

Формат: flag{команда}', 
'flag{exiftool}', 25,
'exif + tool = ?',
'exiftool — швейцарский нож для метаданных. Показывает GPS координаты фото, автора PDF, камеру, дату. Установка: sudo apt install libimage-exiftool-perl. Пример: exiftool image.jpg'),

('Forensics', 'Medium', 'Wireshark Port', 
'Wireshark анализирует трафик. Какой порт использует HTTP?

Формат: flag{число}', 
'flag{80}', 20,
'HTTP работает на том же порту что и веб-сайты. HTTPS — это 443.',
'HTTP использует порт 80 (незашифрованный). HTTPS — 443 (SSL/TLS). Wireshark фильтр: tcp.port == 80. Другие порты: 21 FTP, 22 SSH, 25 SMTP, 3306 MySQL.'),

('Forensics', 'Hard', 'Volatility Framework', 
'Volatility — анализ дампов памяти. Какая команда показывает список процессов?

Варианты: pslist, proclist, processes, tasklist

Формат: flag{команда}', 
'flag{pslist}', 40,
'ps = process, list = список',
'Volatility — фреймворк для анализа RAM дампов. Команда: volatility -f memdump.raw --profile=Win7SP1x64 pslist. Находит скрытые процессы, пароли, ключи шифрования.');

-- ============================================
-- 🕵️ OSINT (6 задач)
-- ============================================

INSERT INTO "Tasks" ("Category", "Difficulty", "Title", "Description", "Flag", "Points", "Hint", "Solution") VALUES
('OSINT', 'Easy', 'Google Dorking', 
'Google Dork — специальные запросы. Какой оператор ищет только на конкретном сайте?

Пример: ____:example.com

Формат: flag{оператор}', 
'flag{site}', 10,
'Этот оператор ограничивает поиск конкретным доменом.',
'Google Dork site: ищет только на указанном сайте. Примеры: site:github.com password, site:edu filetype:pdf. Другие операторы: intitle:, inurl:, filetype:, cache:'),

('OSINT', 'Easy', 'WHOIS Service', 
'WHOIS — база данных доменов. Какой порт использует WHOIS?

Формат: flag{число}', 
'flag{43}', 15,
'WHOIS использует нестандартный порт (не 80/443).',
'WHOIS работает на порту 43. Запрос: whois example.com. Показывает владельца домена, дату регистрации, nameservers. Для анонимности: WHOIS privacy protection.'),

('OSINT', 'Easy', 'DNS A Record', 
'DNS преобразует домены в IP. Какая запись указывает на IPv4 адрес?

Варианты: A, AAAA, CNAME, MX

Формат: flag{тип} (uppercase)', 
'flag{A}', 10,
'A record = Address record (адрес IPv4)',
'DNS записи: A (IPv4), AAAA (IPv6), CNAME (алиас), MX (почта), TXT (текст). Проверка: dig example.com A или nslookup example.com'),

('OSINT', 'Medium', 'SSH Port', 
'Shodan — поисковик для устройств. Какой порт по умолчанию использует SSH?

Формат: flag{число}', 
'flag{22}', 20,
'SSH — Secure Shell. Порт двузначный, начинается с 2.',
'SSH использует порт 22. Подключение: ssh user@host. Shodan находит SSH сервера: port:22 country:"RU". Защита: смена порта, ключи вместо паролей, fail2ban.'),

('OSINT', 'Medium', 'Wayback Machine', 
'Internet Archive сохраняет старые версии сайтов. На каком домене этот сервис?

Формат: flag{домен.zone}', 
'flag{archive.org}', 25,
'Archive.org — домен Internet Archive.',
'Wayback Machine (archive.org) сохраняет снимки сайтов с 1996 года. Полезно для: восстановления удалённого контента, анализа изменений, OSINT расследований. Запрос: web.archive.org/web/*/example.com'),

('OSINT', 'Hard', 'Subdomain Enumeration', 
'Какая утилита находит поддомены сайта через DNS bruteforce?

Варианты: subfinder, sublist3r, nmap, whois

Формат: flag{название}', 'flag{sublist3r}', 35,
'Название начинается с sub...',
'sublist3r — инструмент поиска поддоменов через поисковики и сертификаты. Установка: pip install sublist3r. Пример: sublist3r -d example.com. Альтернативы: amass, subfinder.');

-- ============================================
-- ⚙️ REVERSE ENGINEERING (6 задач)
-- ============================================

INSERT INTO "Tasks" ("Category", "Difficulty", "Title", "Description", "Flag", "Points", "Hint", "Solution") VALUES
('Reverse', 'Easy', 'ASCII Table', 
'Декодируй ASCII числа:
102 108 97 103 123 97 115 99 105 105 125

💡 chr(102) = "f"', 
'flag{ascii}', 15,
'В Python: chr(102) выводит символ. Попробуй для каждого числа!',
'ASCII таблица: 65=A, 97=a, 48=0. Декодирование: "".join(chr(x) for x in [102,108,97,103,123,97,115,99,105,105,125]). В reverse часто встречается XOR, base64, ASCII кодирование.'),

('Reverse', 'Easy', 'Hex to Text', 
'Hex в текст:
666c61677b686578616465636f64657d

💡 Hex decoder', 
'flag{hexadecode}', 10,
'Используй hex decoder или команду xxd',
'Hex декодирование: echo "666c61677b686578616465636f64657d" | xxd -r -p. В реверсе hex часто встречается в шеллкоде, дампах памяти, исполняемых файлах.'),

('Reverse', 'Easy', 'Linux Disassembler', 
'Какая утилита дизассемблирует бинарники в Linux?

Варианты: objdump, strings, file, gdb

Формат: flag{команда}', 
'flag{objdump}', 10,
'obj + dump = дамп объектного файла',
'objdump дизассемблирует бинарники: objdump -d binary. Показывает ассемблерный код. Альтернативы: radare2 (r2), IDA Pro, Ghidra. Флаги: -M intel (синтаксис Intel), -S (секции).'),

('Reverse', 'Medium', 'GDB Command', 
'GDB — отладчик. Какая команда запускает программу?

Варианты: start, run, exec, go

Формат: flag{команда}', 
'flag{run}', 25,
'Команда из трёх букв, начинается с r...',
'GDB команды: run (запуск), break (точка останова), continue, step, print, disassemble. Пример сессии: gdb ./program → break main → run → step → print variable.'),

('Reverse', 'Medium', 'ELF Magic Bytes', 
'ELF — формат исполняемых файлов Linux. С каких hex байтов начинается ELF?

Формат: flag{байты} (lowercase, без пробелов)', 
'flag{7f454c46}', 20,
'ELF начинается с 0x7F и букв ELF в hex.',
'ELF magic: 7F 45 4C 46 (0x7F = DEL, "ELF"). Проверка: xxd binary | head. ELF структура: header → program headers → sections. Инструменты: readelf, objdump, checksec.'),

('Reverse', 'Hard', 'Anti-Debug Function', 
'Какая функция в Linux проверяет наличие отладчика?

Варианты: ptrace, isDebuggerPresent, check_debug, anti_debug

Формат: flag{функция}', 
'flag{ptrace}', 40,
'Эта функция используется для трассировки процессов.',
'ptrace — системный вызов Linux для отладки. Anti-debug: if (ptrace(PTRACE_TRACEME, 0, 1, 0) < 0) exit(1); — если уже под отладчиком, выход. Обход: патчинг бинарника, LD_PRELOAD.');

-- ============================================
-- 💥 BINARY EXPLOITATION (6 задач)
-- ============================================

INSERT INTO "Tasks" ("Category", "Difficulty", "Title", "Description", "Flag", "Points", "Hint", "Solution") VALUES
('Pwn', 'Easy', 'Buffer Overflow Concept', 
'Buffer Overflow — переполнение буфера. Если char buf[8] вмещает 8 байт, что будет при записи 20 байт?

A) Ошибка компиляции
B) Перезапись соседней памяти
C) Ничего

Формат: flag{буква} (lowercase)', 
'flag{b}', 15,
'Буфер переполнится и перезапишет соседние данные в памяти.',
'Buffer Overflow — классическая уязвимость. При переполнении перезаписываются: return address (для захвата контроля), переменные, указатели. Защита: stack canaries, ASLR, DEP/NX.'),

('Pwn', 'Easy', 'Stack Memory', 
'Где хранятся локальные переменные функции?

Варианты: stack, heap, data, text

Формат: flag{ответ}', 
'flag{stack}', 10,
'Локальные переменные хранятся в стеке (stack).',
'Stack — LIFO структура для локальных переменных, return addresses. Heap — динамическая память (malloc). Data — глобальные/статические. Text — код программы.'),

('Pwn', 'Easy', 'System Function', 
'Какая C функция выполняет команды shell?

Варианты: system, exec, shell, run

Формат: flag{функция}', 
'flag{system}', 10,
'Функция из 6 букв, часто используется в C.',
'system() выполняет shell команды: system("/bin/sh"). Уязвимость: если атакующий контролирует аргумент — RCE. Безопаснее: execve(). Пример эксплойта: переполнение → перезапись → вызов system("/bin/sh").'),

('Pwn', 'Medium', 'Return Address Location', 
'Где хранится return address функции?

Варианты: stack, heap, registers, bss

Формат: flag{ответ}', 
'flag{stack}', 25,
'Return address — адрес возврата из функции. Где он хранится?',
'Return address хранится в стеке. При переполнении можно перезаписать его и перенаправить выполнение. Защита: stack canaries (случайное значение перед return address).'),

('Pwn', 'Medium', 'NOP Sled Purpose', 
'NOP sled (0x90) используется в эксплойтах для:

A) Увеличения размера
B) Упрощения попадания в shellcode
C) Обхода антивируса

Формат: flag{буква}', 
'flag{b}', 20,
'NOP sled увеличивает "посадочную площадку" для shellcode.',
'NOP sled (0x90 0x90 ...) — последовательность инструкций "ничего не делать". Зачем? Упрощает попадание в shellcode при неточном адресе. CPU "съезжает" по NOP до shellcode.'),

('Pwn', 'Hard', 'ASLR Config File', 
'Какой файл в Linux настраивает ASLR?

Формат: flag{полный_путь} (например: flag{/proc/sys/kernel/file})', 
'flag{/proc/sys/kernel/randomize_va_space}', 50,
'Файл находится в /proc/sys/kernel/ и содержит randomize в названии.',
'ASLR рандомизирует адреса в памяти. Файл: /proc/sys/kernel/randomize_va_space (0=выкл, 1=частично, 2=полностью). Проверка: cat /proc/self/maps дважды — адреса меняются. Обход: утечка адресов, ROP.');

-- ============================================
-- 🎲 MISCELLANEOUS (6 задач)
-- ============================================

INSERT INTO "Tasks" ("Category", "Difficulty", "Title", "Description", "Flag", "Points", "Hint", "Solution") VALUES
('Misc', 'Easy', 'Morse Code', 
'Азбука Морзе. Декодируй:
..-. .-.. .- --. .-..-. -- --- .-. ... . .-.-.-.

💡 morsecode.world', 
'flag{morse}', 15,
'Используй онлайн декодер азбуки Морзе.',
'Морзе: точка (·) = короткий сигнал, тире (−) = длинный. История: изобретена в 1838, использовалась в телеграфе, радио. Инструменты: morsecode.world, CyberChef.'),

('Misc', 'Easy', 'QR Code Size', 
'Минимальный размер QR кода версии 1?

Варианты: 21x21, 25x25, 29x29, 33x33

Формат: flag{число}x{число}', 
'flag{21x21}', 10,
'QR версии 1 — самый маленький, квадрат 21x21.',
'QR коды: версия 1-40, размер от 21x21 до 177x177. Уровни коррекции: L (7%), M (15%), Q (25%), H (30%). Создание: qrencode, онлайн генераторы. Чтение: zbarimg, телефон.'),

('Misc', 'Easy', 'Steganography Channel', 
'В каком канале PNG чаще прячут данные?

Варианты: Red, Green, Blue, Alpha

Формат: flag{канал}', 
'flag{Alpha}', 10,
'Alpha канал отвечает за прозрачность — идеален для сокрытия данных.',
'Стеганография в PNG: данные прячут в LSB (младшие биты) Alpha канала. Инструменты: steghide, zsteg, stegsolve. Пример: zsteg image.png. Защита: визуальный анализ, статистика.'),

('Misc', 'Medium', 'HTTPS Port', 
'Какой порт использует HTTPS?

Формат: flag{число}', 
'flag{443}', 20,
'HTTP = 80, HTTPS = ?',
'HTTPS = HTTP + SSL/TLS шифрование. Порт 443. Сертификаты: Lets Encrypt (бесплатно). Проверка: openssl s_client -connect site.com:443. Атаки: MITM (без проверки сертификата).'),

('Misc', 'Medium', 'Linux Permissions Owner', 
'В правах rwxr-xr-- что означает rwx?

Варианты: owner, group, others, all

Формат: flag{ответ}', 
'flag{owner}', 25,
'rwx — это права для владельца файла (owner).',
'Linux права: rwxr-xr-- = 754. r(4) w(2) x(1). Структура: owner group others. Изменение: chmod 755 file. Опасность: chmod 777 (полный доступ всем!).'),

('Misc', 'Hard', 'Secure Hash Function', 
'Какая хеш-функция длиной 256 бит безопасна для паролей (с солью)?

Варианты: MD5, SHA1, SHA256, BCRYPT

Формат: flag{название} (uppercase)', 
'flag{SHA256}', 35,
'SHA-256 создаёт хеш длиной 256 бит. Это безопасная функция с солью!',
'SHA-256 безопасен для хранения паролей (с солью!). Лучше: bcrypt, scrypt, Argon2. НЕ используй: MD5 (коллизии), SHA-1 (атаки). Пример: echo -n "password" | sha256sum.');

