#!/bin/bash

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # Без цвета

echo "=============================================="
echo "  Запуск CTF-приложения для обучения"
echo "=============================================="

# --- 1. Проверка системных зависимостей ---
echo -n "Проверка системных библиотек... "
sudo apt-get update > /dev/null 2>&1
sudo apt-get install -y libice6 libsm6 libfontconfig1 curl > /dev/null 2>&1
echo -e "${GREEN}✓${NC}"

# --- 2. Проверка Docker ---
echo -n "Проверка Docker... "
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}не найден${NC}"
    echo "Установка Docker (это может занять 1-2 минуты)..."
    
    curl -fsSL https://get.docker.com -o get-docker.sh 2>/dev/null
    sudo sh get-docker.sh > /dev/null 2>&1
    rm get-docker.sh
    
    sudo usermod -aG docker $USER > /dev/null 2>&1
    
    echo ""
    echo -e "${YELLOW}=============================================="
    echo "  ТРЕБУЕТСЯ ПЕРЕЗАПУСК ТЕРМИНАЛА"
    echo "==============================================${NC}"
    echo "Docker был установлен."
    echo ""
    echo "Что делать дальше:"
    echo "1. Закройте этот терминал (Ctrl+D или закройте окно)"
    echo "2. Откройте новый терминал"
    echo "3. Вернитесь в эту папку и запустите: sudo ./run.sh"
    echo ""
    exit 0
else
    echo -e "${GREEN}✓${NC}"
fi

# --- 3. Запуск базы данных ---
echo -n "Запуск базы данных PostgreSQL... "
sudo docker compose up -d > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    echo "Ошибка при запуске базы данных."
    echo "Попробуйте запустить вручную: sudo docker compose up"
    exit 1
fi

# --- 4. Ожидание готовности БД ---
echo -n "Инициализация базы данных... "
sleep 8
echo -e "${GREEN}✓${NC}"

# --- 5. Запуск приложения ---
echo ""
echo "=============================================="
echo "  Запуск приложения..."
echo "=============================================="
echo ""

chmod +x ./CtfApp
./CtfApp

# --- Завершение работы ---
EXIT_CODE=$?
echo ""
echo "=============================================="
if [ $EXIT_CODE -eq 0 ]; then
    echo -e "${GREEN}Приложение завершено успешно${NC}"
else
    echo -e "${YELLOW}Приложение завершено с кодом: $EXIT_CODE${NC}"
fi
echo "=============================================="

echo -n "Остановка базы данных... "
sudo docker compose down > /dev/null 2>&1
echo -e "${GREEN}✓${NC}"

echo ""
echo "Готово! Спасибо за использование."
