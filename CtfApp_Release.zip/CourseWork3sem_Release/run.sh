#!/bin/bash

echo "=============================================="
echo "  Запуск CTF-приложения для обучения"
echo "=============================================="

chmod +x run.sh

# --- 1. Проверка и установка графических библиотек ---
echo "[1/5] Проверка системных зависимостей..."
sudo apt-get update -qq
sudo apt-get install -y libice6 libsm6 libfontconfig1 curl > /dev/null 2>&1

# --- 2. Проверка и установка Docker ---
if ! command -v docker &> /dev/null; then
    echo "[2/5] Docker не найден. Устанавливаем..."
    
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    rm get-docker.sh

    echo "[2/5] Добавляем пользователя в группу Docker..."
    sudo usermod -aG docker $USER
    
    echo ""
    echo "=============================================="
    echo "  ТРЕБУЕТСЯ ПЕРЕЗАПУСК ТЕРМИНАЛА"
    echo "=============================================="
    echo "Docker был установлен. Для применения изменений:"
    echo "1. Закройте этот терминал"
    echo "2. Откройте новый терминал"
    echo "3. Запустите скрипт снова: ./run.sh"
    echo "=============================================="
    exit 1
else
    echo "[2/5] Docker найден ✓"
fi

# --- 3. Запуск базы данных ---
echo "[3/5] Запуск PostgreSQL..."
docker compose up -d

# --- 4. Ожидание готовности БД ---
echo "[4/5] Ожидание инициализации базы данных (15 сек)..."
sleep 15

# --- 5. Запуск приложения ---
echo "[5/5] Запуск приложения..."
chmod +x ./CtfApp
./CtfApp

# --- Завершение работы ---
echo ""
echo "Приложение было закрыто."
echo "Останавливаем базу данных..."
docker compose down
echo "Готово!"
