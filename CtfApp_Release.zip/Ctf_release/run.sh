#!/bin/bash

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # Без цвета

echo "=============================================="
echo "  Запуск CTF-приложения для обучения"
echo "=============================================="

# --- 1. Проверка системных зависимостей ---
echo -n "Проверка системных библиотек... "
sudo apt-get update > /dev/null 2>&1
sudo apt-get install -y libice6 libsm6 libfontconfig1 curl > /dev/null 2>&1
echo -e "${GREEN}✓${NC}"

# --- 2. Проверка Docker ---
echo -n "Проверка Docker... "
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}не найден${NC}"
    echo "Установка Docker (это может занять 1-2 минуты)..."
    
    curl -fsSL https://get.docker.com -o get-docker.sh 2>/dev/null
    sudo sh get-docker.sh > /dev/null 2>&1
    rm get-docker.sh
    
    sudo usermod -aG docker $USER > /dev/null 2>&1
    
    echo ""
    echo -e "${YELLOW}=============================================="
    echo "  ТРЕБУЕТСЯ ПЕРЕЗАПУСК ТЕРМИНАЛА"
    echo "==============================================${NC}"
    echo "Docker был установлен."
    echo ""
    echo "Что делать дальше:"
    echo "1. Закройте этот терминал (Ctrl+D или закройте окно)"
    echo "2. Откройте новый терминал"
    echo "3. Вернитесь в эту папку и запустите: sudo ./run.sh"
    echo ""
    exit 0
else
    echo -e "${GREEN}✓${NC}"
fi

# --- 3. Определение команды docker compose ---
echo -n "Проверка Docker Compose... "
if command -v docker-compose &> /dev/null; then
    DOCKER_COMPOSE="docker-compose"
    echo -e "${GREEN}✓ (классический)${NC}"
elif docker compose version &> /dev/null 2>&1; then
    DOCKER_COMPOSE="docker compose"
    echo -e "${GREEN}✓ (плагин)${NC}"
else
    echo -e "${RED}✗${NC}"
    echo "Ошибка: Docker Compose не найден"
    exit 1
fi

# --- 4. Запуск базы данных ---
echo -n "Запуск базы данных PostgreSQL... "
sudo $DOCKER_COMPOSE up -d > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC}"
else
    echo -e "${RED}✗${NC}"
    echo "Ошибка при запуске базы данных."
    echo "Попробуйте запустить вручную: sudo $DOCKER_COMPOSE up"
    exit 1
fi

# --- 5. Проверка и инициализация задач ---
echo -n "Ожидание готовности БД... "
sleep 5
echo -e "${GREEN}✓${NC}"

echo -n "Проверка задач в базе данных... "
# Пробуем посчитать задачи
TASK_COUNT=$(sudo $DOCKER_COMPOSE exec -T ctf-db psql -U admin -d ctf_game -t -c 'SELECT COUNT(*) FROM "Tasks";' 2>/dev/null | xargs)

if [ -z "$TASK_COUNT" ] || [ "$TASK_COUNT" = "0" ]; then
    echo -e "${YELLOW}не найдены${NC}"
    echo ""
    echo "Задачи отсутствуют в базе данных."
    echo "Это может произойти, если volume был создан ранее без init.sql."
    echo ""
    echo "Для загрузки задач необходимо пересоздать базу данных."
    echo -e "${YELLOW}ВНИМАНИЕ: Это удалит все текущие данные (пользователи, прогресс).${NC}"
    echo ""
    read -p "Пересоздать базу с задачами? [y/N]: " CONFIRM
    
    if [[ "$CONFIRM" =~ ^[Yy]$ ]]; then
        echo ""
        echo -n "Останавливаем базу данных... "
        sudo $DOCKER_COMPOSE down -v > /dev/null 2>&1
        echo -e "${GREEN}✓${NC}"
        
        echo -n "Пересоздаём базу с задачами... "
        sudo $DOCKER_COMPOSE up -d > /dev/null 2>&1
        echo -e "${GREEN}✓${NC}"
        
        echo -n "Ожидание инициализации (10 сек)... "
        sleep 10
        echo -e "${GREEN}✓${NC}"
        
        # Проверяем, загрузились ли задачи
        NEW_TASK_COUNT=$(sudo $DOCKER_COMPOSE exec -T ctf-db psql -U admin -d ctf_game -t -c 'SELECT COUNT(*) FROM "Tasks";' 2>/dev/null | xargs)
        if [ -n "$NEW_TASK_COUNT" ] && [ "$NEW_TASK_COUNT" -gt "0" ]; then
            echo -e "${GREEN}Успех! Загружено задач: $NEW_TASK_COUNT${NC}"
        else
            echo -e "${RED}Ошибка: задачи не загрузились. Проверьте init.sql${NC}"
            echo "Попробуйте запустить вручную:"
            echo "  sudo $DOCKER_COMPOSE exec -i ctf-db psql -U admin -d ctf_game < init.sql"
        fi
    else
        echo ""
        echo -e "${YELLOW}Запуск без задач. Приложение может работать некорректно.${NC}"
        echo "Для загрузки задач вручную выполните:"
        echo "  sudo $DOCKER_COMPOSE exec -i ctf-db psql -U admin -d ctf_game < init.sql"
    fi
else
    echo -e "${GREEN}✓ (найдено: $TASK_COUNT)${NC}"
fi

# --- 6. Запуск приложения ---
echo ""
echo "=============================================="
echo "  Запуск приложения..."
echo "=============================================="
echo ""

chmod +x ./CtfApp
./CtfApp

# --- Завершение работы ---
EXIT_CODE=$?
echo ""
echo "=============================================="
if [ $EXIT_CODE -eq 0 ]; then
    echo -e "${GREEN}Приложение завершено успешно${NC}"
else
    echo -e "${YELLOW}Приложение завершено с кодом: $EXIT_CODE${NC}"
fi
echo "=============================================="

echo -n "Остановка базы данных... "
sudo $DOCKER_COMPOSE down > /dev/null 2>&1
echo -e "${GREEN}✓${NC}"

echo ""
echo "Готово! Спасибо за использование."
